<template>
<router-view></router-view>
</template>

<style>


</style>


<script>
import index_el from './views/index_el.vue'

export default {
  name: 'newapp',
  components: {
    index_el,
  }
}
</script>
