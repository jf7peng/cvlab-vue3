.visual_conTop {
  height: 130px;
  margin-bottom: 10px;
}

.visual_conTop .visual_conTop_box {
  height: 100%;
  padding: 0 3px;
}

.visual_conTop .visual_conTop1 {
  width: 20%;
  height: 100%;
  float: left;
}

.visual_conTop .visual_conTop1 > div {
  background: url(../assets/ksh40.png) no-repeat;
  background-size: 100% 100%;
}

.visual_conTop .visual_conTop2 {
  width: 30%;
  height: 100%;
  float: left;
}
.visual_conTop .visual_conTop2 > div {
  background: url(../assets/ksh39.png) no-repeat;
  background-size: 100% 100%;
}

.visual_conTop .visual_conTop_box > div {
  height: 100%;
}

.visual_conTop .visual_conTop_box > div h3 {
  color: #fff;
  font-size: 25px;
  padding: 16px 0 0 20px;
}

.visual_conTop .visual_conTop_box > div p {
  width: 33%;
  float: left;
  line-height: 85px;
  color: #20dbfd;
  text-shadow: 0 0 25px #00d8ff;
  font-size: 60px;
  font-family: "yjsz";
  text-align: right;
}

.visual_conTop .visual_conTop_box > div .conTop_smil {
  width: 50%;
  height: 60px;
  float: left;
  padding-top: 23px;
}

.visual_conTop .visual_conTop_box > div .conTop_smil a {
  display: block;
  line-height: 20px;
  text-align: left;
  color: #fff;
  padding-left: 25px;
}

.visual_conTop .visual_conTop_box > div .conTop_smil span {
  width: 32px;
  display: inline-block;
  margin-left: 3px;
}

.visual_conTop .visual_conTop_box > div .conTop_smil a.sz {
  color: #fe3e12;
  font-size: 18px;
}
.visual_conTop .visual_conTop_box > div .conTop_smil a.hah {
  color: #fff;
  font-size: 18px;
}

.visual_conTop .visual_conTop_box > div .conTop_smil a.xd {
  color: #12fe81;
  font-size: 18px;
}

.visual_conTop .visual_conTop_box > div .conTop_smil a.null {
  visibility: hidden;
}




###
<div class="visual_conTop">
    <div class="visual_conTop_box visual_conTop1">
      <div>
        <h3>RSU</h3>
        <p>215</p>
        <div class="conTop_smil">
          <a class="sz"
            >日环比:<span>+5%</span><i class="fa fa-long-arrow-up"></i
          ></a>
          <a class="xd"
            >周环比:<span>-4%</span><i class="fa fa-long-arrow-down"></i
          ></a>
        </div>
      </div>
    </div>
    <div class="visual_conTop_box visual_conTop2">
      <div>
        <h3>高速拥堵指数</h3>
        <p>1.4</p>
        <div class="conTop_smil">
          <a class="hah">缓行</a>
          <a class="hah">平均车速<span>120</span>KM/H</a>
        </div>
      </div>
    </div>

    <div class="visual_conTop_box visual_conTop1">
      <div>
        <h3>当前网联车辆数</h3>
        <p>108</p>
        <div class="conTop_smil">
          <a class="sz"
            >日环比:<span>+3%</span><i class="fa fa-long-arrow-up"></i
          ></a>
          <a class="xd"
            >周环比:<span>-2%</span><i class="fa fa-long-arrow-down"></i
          ></a>
        </div>
      </div>
    </div>
    <div class="visual_conTop_box visual_conTop2">
      <div>
        <h3>基础设施故障数(起)</h3>
        <p>121</p>
        <div class="conTop_smil">
          <a class="null">null</a>
          <a class="xd"
            >月环比:<span>-2%</span><i class="fa fa-long-arrow-down"></i
          ></a>
        </div>
      </div>
    </div>
    <div class="clear"></div>
  </div>