<template>
  <div class="first_01">
    <h2>
      <span class="head">智库视野</span>
      <a
        class="more"
        href="http://naes.bjtu.edu.cn/index.php?m=content&amp;c=index&amp;a=lists&amp;catid=23"
        target="_blank"
        >更多&gt;&gt;</a
      >
    </h2>

    <!-- 热点新闻 -->
    <div class="news-hot">
      <div class="content">
        <!--
                                 <h3><a href="http://naes.bjtu.edu.cn/index.php?m=content&c=index&a=show&catid=16&id=954" target="_blank" title="北京交通大学威海校区党委书记孙文博来我院交流座谈">北京交通大学威海校区党委书记孙文博来我院交流座谈</a></h3>
             <div class="content1"></div>
                              -->
      </div>
      <div class="tuij_news">
        <ul>
          <li>
            <span class="fright">[2021-11-12]</span
            ><a
              href="http://naes.bjtu.edu.cn/index.php?m=content&amp;c=index&amp;a=show&amp;catid=23&amp;id=953"
              target="_blank"
              title="关于当前金融安全形势的认识与思考"
              >关于当前金融安全形势的认识与思考</a
            >
          </li>
          <li>
            <span class="fright">[2021-11-11]</span
            ><a
              href="http://naes.bjtu.edu.cn/index.php?m=content&amp;c=index&amp;a=show&amp;catid=23&amp;id=952"
              target="_blank"
              title="周道许：立足国民经济和社会发展全局，推动铁路建设工作高质量发展"
              >周道许：立足国民经济和社会发展全局，推...</a
            >
          </li>
          <li>
            <span class="fright">[2019-07-12]</span
            ><a
              href="http://naes.bjtu.edu.cn/index.php?m=content&amp;c=index&amp;a=show&amp;catid=23&amp;id=887"
              target="_blank"
              title="关于科学认识和运用统一战线法宝的几个问题"
              >关于科学认识和运用统一战线法宝的几个问题</a
            >
          </li>
          <li>
            <span class="fright">[2019-02-16]</span
            ><a
              href="http://naes.bjtu.edu.cn/index.php?m=content&amp;c=index&amp;a=show&amp;catid=23&amp;id=857"
              target="_blank"
              title="桥水持仓大曝光！最新报告看空几乎一切金融资产"
              >桥水持仓大曝光！最新报告看空几乎一切金...</a
            >
          </li>
          <li>
            <span class="fright">[2019-02-16]</span
            ><a
              href="http://naes.bjtu.edu.cn/index.php?m=content&amp;c=index&amp;a=show&amp;catid=23&amp;id=856"
              target="_blank"
              title="中国社会科学院国家高端智库论坛暨2019年经济形势座谈会在京举行"
              >中国社会科学院国家高端智库论坛暨2019年...</a
            >
          </li>
          <li>
            <span class="fright">[2019-02-12]</span
            ><a
              href="http://naes.bjtu.edu.cn/index.php?m=content&amp;c=index&amp;a=show&amp;catid=23&amp;id=855"
              target="_blank"
              title="Ray Dalio：论国家经济成败的原因"
              >Ray Dalio：论国家经济成败的原因</a
            >
          </li>
          <li>
            <span class="fright">[2019-02-12]</span
            ><a
              href="http://naes.bjtu.edu.cn/index.php?m=content&amp;c=index&amp;a=show&amp;catid=23&amp;id=854"
              target="_blank"
              title="县级地方政府债务问题，不能被遗忘……｜社会科学报"
              >县级地方政府债务问题，不能被遗忘……...</a
            >
          </li>
        </ul>
      </div>
    </div>
    <div class="clear"></div>
  </div>
</template>


<style >
div.first_01 {
  background-color: #ffffff9c;
  float: right;
  width: 490px;
  margin-top: 0px;
  margin-left: 0px;
  padding: 0px 5px 0px 5px;
  height: 450px;
  border-bottom: medium solid #ccc;
}

div.first_01 h2 {
  background: url(../img/lanmu_bg01.png) repeat-x scroll 0px 0px transparent;
  height: 30px;
  line-height: 30px;
  padding-left: 10px;
  margin-bottom: 10px;
}

div.first_01 h2 .head {
  background: url(../img/lanmu_tit01.png) no-repeat scroll 0px 0px transparent;
  color: #01377f;
  font-family: 微软雅黑;
  display: block;
  float: left;
  font-size: 16px;
  font-weight: bold;
  height: 30px;
  text-align: center;
  width: 110px;
}

div.first_01 h2 .more {
  float: right;
  height: 30px;
  line-height: 30px;
  text-align: right;
  width: 110px;
  font-family: "宋体";
  font-size: 16px;
  color: #000000;
  padding-right: 5px;
}



div.first_01 .news-hot {
  float: left;
  width: 480px;
  margin-left: 0px;
  height: auto;
}
div.first_01 .news-hot .tuij_news {
  height: auto;
}

div.first_01 .news-hot .content {
  padding: 0 0 0 0 px;
  line-height: 25px;
  text-align: center;
  vertical-align: middle;
}

div.first_01 .news-hot .tuij_news li {
  line-height: 2em;
  list-style: none;
  padding-left: 0px;
}

.fright {
  float: right;
}
a:link {
  color: #000000;
  text-decoration: none;
}

div.tuij_news ul {
  display: block;
  list-style-type: disc;
  margin-block-start: 1em;
  margin-block-end: 1em;
  margin-inline-start: 0px;
  margin-inline-end: 0px;
  padding-inline-start: 40px;
}

div.clear {
    clear: both;
}

div.tuij_news ul li {
  display: list-item;
  line-height: 2em;
  list-style: none;
  text-align: left;
}
</style>